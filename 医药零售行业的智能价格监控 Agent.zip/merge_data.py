# -*- coding: utf-8 -*-
"""
合并药师帮数据并生成CSV - 修复商品URL
"""

import json
import csv
import re
import os

TODAY = "2026-04-15"
OUTPUT_DIR = r"D:\desktop\work"
DUMATE_DIR = r"D:\desktop\work\.dumate"


def parse_json_file(filepath):
    """解析JSON文件，提取药品数据"""
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    # 提取JSON部分
    lines = content.strip().split("\n")
    json_line = None
    for line in lines:
        if '"page":' in line or '\\"page\\":' in line:
            json_line = line
            break

    if json_line:
        if json_line.startswith('"') and json_line.endswith('"'):
            json_line = json_line[1:-1]
            json_line = json_line.replace('\\"', '"')
            json_line = json_line.replace("\\\\", "\\")

        try:
            data = json.loads(json_line)
            return data.get("drugs", [])
        except json.JSONDecodeError as e:
            print(f"JSON解析错误: {e}")
            return []
    return []


def main():
    # 读取所有数据文件
    all_drugs = []

    # 贝乐妥数据（3页）
    for i in range(1, 4):
        filepath = os.path.join(DUMATE_DIR, f"page{i}_full.json")
        if os.path.exists(filepath):
            drugs = parse_json_file(filepath)
            print(f"贝乐妥第{i}页: {len(drugs)} 条")
            all_drugs.extend(drugs)

    # 康舒妥数据
    filepath = os.path.join(DUMATE_DIR, "kangshutuo.json")
    if os.path.exists(filepath):
        drugs = parse_json_file(filepath)
        print(f"康舒妥: {len(drugs)} 条")
        all_drugs.extend(drugs)

    # 弘博泰数据
    filepath = os.path.join(DUMATE_DIR, "hongbotai.json")
    if os.path.exists(filepath):
        drugs = parse_json_file(filepath)
        print(f"弘博泰: {len(drugs)} 条")
        all_drugs.extend(drugs)

    print(f"\n总计: {len(all_drugs)} 条记录")

    # 去重
    seen = set()
    unique = []
    for d in all_drugs:
        key = f"{d['shop']}|{d['product']}|{d['spec']}|{d['price']}|{d['zkPrice']}|{d['minQty']}"
        if key not in seen:
            seen.add(key)
            unique.append(d)

    print(f"去重后: {len(unique)} 条记录")

    # 保存CSV - 添加商品URL
    cols = [
        "序号",
        "店铺名",
        "商品名",
        "通用名",
        "规格",
        "价格",
        "折后价",
        "起购量",
        "生产日期",
        "有效期至",
        "生产厂家",
        "是否近效期",
        "配送说明",
        "统计时间",
        "商品URL",
    ]

    output_path = os.path.join(
        OUTPUT_DIR, f"药师帮_最终版_{TODAY.replace('-', '')}.csv"
    )
    with open(output_path, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        writer.writeheader()
        for i, row in enumerate(unique, 1):
            # 构建商品URL - 使用wholesaleid
            wholesaleid = row.get("wholesaleid", "")
            product_url = (
                f"https://dian.ysbang.cn/#/drugDetail?id={wholesaleid}"
                if wholesaleid
                else ""
            )

            writer.writerow(
                {
                    "序号": i,
                    "店铺名": row.get("shop", ""),
                    "商品名": row.get("product", ""),
                    "通用名": row.get("drugName", ""),
                    "规格": row.get("spec", ""),
                    "价格": row.get("price", ""),
                    "折后价": row.get("zkPrice", ""),
                    "起购量": row.get("minQty", ""),
                    "生产日期": row.get("prodDate", ""),
                    "有效期至": row.get("validDate", ""),
                    "生产厂家": row.get("factory", ""),
                    "是否近效期": row.get("isNear", ""),
                    "配送说明": row.get("delivery", ""),
                    "统计时间": row.get("today", TODAY),
                    "商品URL": product_url,
                }
            )

    print(f"\n已保存到: {output_path}")


if __name__ == "__main__":
    main()
