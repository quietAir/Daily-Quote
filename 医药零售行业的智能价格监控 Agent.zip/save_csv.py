# -*- coding: utf-8 -*-
import csv
import json
import codecs

# 采集的数据（从浏览器提取）
data = []

# 表头
headers = [
    "序号",
    "店铺名",
    "商品名",
    "通用名",
    "规格",
    "价格",
    "折后价",
    "起购量",
    "生产日期",
    "有效期至",
    "生产厂家",
    "是否近效期",
    "配送说明",
    "统计时间",
    "商品URL",
]

# 保存CSV文件
output_path = r"D:\desktop\work\药师帮_最终版_20260415.csv"

with open(output_path, "w", encoding="utf-8-sig", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(headers)

    # 这里需要从浏览器获取数据后填充
    print(f"CSV template created: {output_path}")
    print("Waiting for data from browser...")
