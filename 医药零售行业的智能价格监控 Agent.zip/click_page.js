async page => {
  const result = await page.evaluate(() => {
    const lis = Array.from(document.querySelectorAll('li'));
    const li2 = lis.find(li => (li.innerText||'').trim() === '2');
    if (li2) {
      li2.click();
      return 'clicked page 2';
    }
    return 'page 2 button not found';
  });
  return result;
}
