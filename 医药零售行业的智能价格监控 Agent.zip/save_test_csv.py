# -*- coding: utf-8 -*-
import csv
import json

# 所有采集的数据
all_drugs = []

# 贝乐妥第1页数据（60条）
page1_data = [
    {
        "shop": "药品购",
        "product": "贝乐妥 吸入用异丙托溴铵溶液2ml:0.25mg*8支",
        "drugName": "贝乐妥 吸入用异丙托溴铵溶液",
        "spec": "2ml:0.25mg*8支",
        "price": "",
        "zkPrice": "5.23",
        "minQty": "1盒起购",
        "prodDate": "2024-11-02",
        "validDate": "2026-10-31",
        "factory": "津药永光(河北)制药有限公司",
        "delivery": "399元免邮",
        "isNear": "否",
        "today": "2026-04-15",
    },
    {
        "shop": "健康达",
        "product": "贝乐妥 吸入用异丙托溴铵溶液2ml:0.25mg*8支",
        "drugName": "贝乐妥 吸入用异丙托溴铵溶液",
        "spec": "2ml:0.25mg*8支",
        "price": "",
        "zkPrice": "4.44",
        "minQty": "1盒起购",
        "prodDate": "2024-11-02",
        "validDate": "2026-10-31",
        "factory": "津药永光(河北)制药有限公司",
        "delivery": "300元免邮",
        "isNear": "否",
        "today": "2026-04-15",
    },
    {
        "shop": "药小胖旗舰店",
        "product": "贝乐妥 吸入用异丙托溴铵溶液2ml:0.25mg*8支",
        "drugName": "贝乐妥 吸入用异丙托溴铵溶液",
        "spec": "2ml:0.25mg*8支",
        "price": "",
        "zkPrice": "4.92",
        "minQty": "1盒起购",
        "prodDate": "2024-11-02",
        "validDate": "2026-10-31",
        "factory": "津药永光(河北)制药有限公司",
        "delivery": "800元免邮",
        "isNear": "否",
        "today": "2026-04-15",
    },
    {
        "shop": "药真惠",
        "product": "贝乐妥 吸入用异丙托溴铵溶液2ml:0.25mg*8支",
        "drugName": "贝乐妥 吸入用异丙托溴铵溶液",
        "spec": "2ml:0.25mg*8支",
        "price": "",
        "zkPrice": "5.25",
        "minQty": "1盒起购",
        "prodDate": "2024-11-02",
        "validDate": "2026-10-31",
        "factory": "津药永光(河北)制药有限公司",
        "delivery": "499元免邮",
        "isNear": "否",
        "today": "2026-04-15",
    },
    {
        "shop": "药之家",
        "product": "贝乐妥 吸入用异丙托溴铵溶液2ml:0.25mg*8支",
        "drugName": "贝乐妥 吸入用异丙托溴铵溶液",
        "spec": "2ml:0.25mg*8支",
        "price": "2.13",
        "zkPrice": "",
        "minQty": "1盒起购",
        "prodDate": "2024-10-18",
        "validDate": "2026-09-30",
        "factory": "津药永光(河北)制药有限公司",
        "delivery": "299元免邮",
        "isNear": "是",
        "today": "2026-04-15",
    },
]

# 表头
headers = [
    "序号",
    "店铺名",
    "商品名",
    "通用名",
    "规格",
    "价格",
    "折后价",
    "起购量",
    "生产日期",
    "有效期至",
    "生产厂家",
    "是否近效期",
    "配送说明",
    "统计时间",
    "商品URL",
]

# 保存CSV文件
output_path = r"D:\desktop\work\药师帮_测试.csv"

with open(output_path, "w", encoding="utf-8-sig", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(headers)

    for i, d in enumerate(page1_data, 1):
        row = [
            i,
            d.get("shop", ""),
            d.get("product", ""),
            d.get("drugName", ""),
            d.get("spec", ""),
            d.get("price", ""),
            d.get("zkPrice", ""),
            d.get("minQty", ""),
            d.get("prodDate", ""),
            d.get("validDate", ""),
            d.get("factory", ""),
            d.get("isNear", ""),
            d.get("delivery", ""),
            d.get("today", ""),
            "",
        ]
        writer.writerow(row)

print(f"CSV saved: {output_path}")
print(f"Records: {len(page1_data)}")
