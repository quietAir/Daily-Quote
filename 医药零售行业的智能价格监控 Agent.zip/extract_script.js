async page => {
  const result = await page.evaluate(() => {
    const vuexRaw = localStorage.getItem('vuex');
    const vuex = JSON.parse(vuexRaw);
    const dl = vuex.drugList;
    const TODAY = '2026-04-15';
    
    const drugs = (dl.drugList || []).map((d) => {
      let jcm = {};
      try { jcm = JSON.parse(d.joinCarMap || '{}'); } catch(e) {}
      
      const price = parseFloat(d.price || 0);
      const dis   = parseFloat(d.disPrice || 0);
      const ben   = parseFloat(d.benefitPrice || 0);
      const zkPrice = dis > 0 ? dis.toFixed(2) : ben > 0 ? (price - ben).toFixed(2) : '';
      
      let isNear = '否';
      if (d.nearEffectStatus === 1) isNear = '是';
      else if (d.valid_date) {
        const days = (new Date(d.valid_date) - new Date(TODAY)) / 86400000;
        if (days < 180) isNear = '是';
      }
      
      const drugname = d.drugname || '';
      const m = drugname.match(/^(\d+盒(?:起购|包邮)\s+)/);
      const productName = m ? drugname.substring(m[0].length).trim() : drugname;
      
      const parts = [];
      const wl = d.wholesaleLabel;
      if (wl && typeof wl === 'object' && wl.labelName) parts.push(wl.labelName);
      if (d.delivery_floor && d.delivery_floor !== '0') parts.push(d.delivery_floor + '元免邮');
      if (jcm.stockStatus)  parts.push(jcm.stockStatus);
      if (jcm.limitMessage) parts.push(jcm.limitMessage);
      
      let productUrl = '';
      if (d.detailUrl)    productUrl = d.detailUrl;
      else if (d.url)     productUrl = d.url;
      else if (d.href)    productUrl = d.href;
      else if (d.jumpUrl) productUrl = d.jumpUrl;
      else if (d.productUrl) productUrl = d.productUrl;
      else if (d.id)      productUrl = 'https://dian.ysbang.cn/#/drugDetail?id=' + d.id;
      
      return {
        shop:      d.provider_name  || '',
        product:   productName,
        drugName:  d.cn_name       || '',
        spec:      d.specification  || '',
        price:     price > 0 ? price.toFixed(2) : '',
        zkPrice,
        minQty:    (d.step || d.minamount || '') + '盒起购',
        prodDate:  d.prodDate       || '',
        validDate: d.valid_date     || '',
        factory:   d.manufacturer  || '',
        delivery:  parts.join('; '),
        isNear,
        today:     TODAY,
        url:       productUrl
      };
    });
    
    window._hbt = drugs;
    return { page: dl.page, total: dl.totalNumber, count: drugs.length, drugs };
  });
  
  return result;
}
