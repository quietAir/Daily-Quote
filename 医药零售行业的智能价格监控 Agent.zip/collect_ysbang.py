# -*- coding: utf-8 -*-
"""
药师帮数据采集 - 使用playwright-cli
"""

import subprocess
import json
import csv
import time
import re
from datetime import datetime

TODAY = datetime.now().strftime("%Y-%m-%d")
OUTPUT_DIR = r"D:\desktop\work"


def run_eval(script):
    """执行playwright-cli eval命令"""
    # 转义引号
    escaped = script.replace('"', '\\"')
    result = subprocess.run(
        f'playwright-cli eval "{escaped}"',
        shell=True,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    # 从输出中提取JSON结果
    lines = result.stdout.strip().split("\n")
    for line in lines:
        if line.startswith("[") or line.startswith("{"):
            return json.loads(line)
    return None


def extract_page_data():
    """提取当前页面的完整数据"""
    script = (
        """(() => {
const v = JSON.parse(localStorage.getItem('vuex'));
const dl = v.drugList;
const TODAY = '%s';

const drugs = (dl.drugList || []).map((d) => {
  let jcm = {};
  try { jcm = JSON.parse(d.joinCarMap || '{}'); } catch(e) {}

  const price = parseFloat(d.price || 0);
  const dis = parseFloat(d.disPrice || 0);
  const ben = parseFloat(d.benefitPrice || 0);
  const zkPrice = dis > 0 ? dis.toFixed(2) : ben > 0 ? (price - ben).toFixed(2) : '';

  let isNear = '否';
  if (d.nearEffectStatus === 1) isNear = '是';
  else if (d.valid_date) {
    const days = (new Date(d.valid_date) - new Date(TODAY)) / 86400000;
    if (days < 180) isNear = '是';
  }

  const drugname = d.drugname || '';
  const m = drugname.match(/^(\\d+盒(?:起购|包邮)\\s+)/);
  const productName = m ? drugname.substring(m[0].length).trim() : drugname;

  const parts = [];
  const wl = d.wholesaleLabel;
  if (wl && typeof wl === 'object' && wl.labelName) parts.push(wl.labelName);
  if (d.delivery_floor && d.delivery_floor !== '0') parts.push(d.delivery_floor + '元免邮');
  if (jcm.stockStatus) parts.push(jcm.stockStatus);
  if (jcm.limitMessage) parts.push(jcm.limitMessage);

  let productUrl = '';
  if (d.detailUrl) productUrl = d.detailUrl;
  else if (d.url) productUrl = d.url;
  else if (d.href) productUrl = d.href;
  else if (d.jumpUrl) productUrl = d.jumpUrl;
  else if (d.productUrl) productUrl = d.productUrl;
  else if (d.id) productUrl = 'https://dian.ysbang.cn/#/drugDetail?id=' + d.id;

  return {
    shop: d.provider_name || '',
    product: productName,
    drugName: d.cn_name || '',
    spec: d.specification || '',
    price: price > 0 ? price.toFixed(2) : '',
    zkPrice: zkPrice,
    minQty: (d.step || d.minamount || '') + '盒起购',
    prodDate: d.prodDate || '',
    validDate: d.valid_date || '',
    factory: d.manufacturer || '',
    delivery: parts.join('; '),
    isNear: isNear,
    today: TODAY,
    url: productUrl
  };
});

return { page: dl.page, total: dl.totalNumber, count: drugs.length, drugs: drugs };
})()
"""
        % TODAY
    )

    return run_eval(script)


def click_page(page_num):
    """点击翻页按钮"""
    script = f"""(() => {{
const lis = Array.from(document.querySelectorAll('li'));
const targetPage = '{page_num}';
const liN = lis.find(li => (li.innerText||'').trim() === targetPage);
if (liN) {{ liN.click(); return 'clicked page-' + targetPage; }}
return 'page button not found';
}})()
"""
    result = run_eval(script)
    print(f"翻页结果: {result}")
    time.sleep(8)  # 等待数据加载


def save_csv(all_drugs, filename):
    """保存数据到CSV文件"""
    cols = [
        "序号",
        "店铺名",
        "商品名",
        "通用名",
        "规格",
        "价格",
        "折后价",
        "起购量",
        "生产日期",
        "有效期至",
        "生产厂家",
        "是否近效期",
        "配送说明",
        "统计时间",
        "商品URL",
    ]

    # 去重
    seen = set()
    unique = []
    for d in all_drugs:
        key = f"{d['shop']}|{d['product']}|{d['spec']}|{d['price']}|{d['zkPrice']}|{d['minQty']}"
        if key not in seen:
            seen.add(key)
            unique.append(d)

    filepath = f"{OUTPUT_DIR}\\{filename}"
    with open(filepath, "w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        writer.writeheader()
        for i, row in enumerate(unique, 1):
            writer.writerow(
                {
                    "序号": i,
                    "店铺名": row.get("shop", ""),
                    "商品名": row.get("product", ""),
                    "通用名": row.get("drugName", ""),
                    "规格": row.get("spec", ""),
                    "价格": row.get("price", ""),
                    "折后价": row.get("zkPrice", ""),
                    "起购量": row.get("minQty", ""),
                    "生产日期": row.get("prodDate", ""),
                    "有效期至": row.get("validDate", ""),
                    "生产厂家": row.get("factory", ""),
                    "是否近效期": row.get("isNear", ""),
                    "配送说明": row.get("delivery", ""),
                    "统计时间": row.get("today", TODAY),
                    "商品URL": row.get("url", ""),
                }
            )

    print(f"已保存 {len(unique)} 条记录到 {filepath}")
    return filepath


def collect_drug(drug_name, search_key, expected_pages):
    """采集单个药品的数据"""
    print(f"\n开始采集: {drug_name}")
    all_drugs = []

    # 提取每一页的数据
    for page in range(1, expected_pages + 1):
        print(f"  提取第 {page} 页...")
        data = extract_page_data()
        if data and "drugs" in data:
            all_drugs.extend(data["drugs"])
            print(f"    获取 {len(data['drugs'])} 条记录")

        # 如果不是最后一页，翻页
        if page < expected_pages:
            click_page(page + 1)

    # 保存CSV
    filename = f"药师帮_{drug_name}.csv"
    return save_csv(all_drugs, filename)


if __name__ == "__main__":
    print("药师帮数据采集脚本")
    print("请确保浏览器已打开药师帮网站并搜索了目标药品")
    print("当前时间:", TODAY)
