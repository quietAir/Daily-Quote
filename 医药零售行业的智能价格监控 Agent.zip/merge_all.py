import json
import csv
import os
import re


def extract_json_from_file(filepath):
    """从playwright输出文件或纯JSON文件中提取JSON"""
    with open(filepath, "r", encoding="utf-8") as f:
        content = f.read()

    # 首先尝试直接解析为JSON（纯JSON格式）
    try:
        data = json.loads(content)
        if isinstance(data, dict) and "drugs" in data:
            return data
    except:
        pass

    # 查找JSON字符串（在引号内的JSON - playwright输出格式）
    match = re.search(r'"(\{.*\})"', content, re.DOTALL)
    if match:
        json_str = match.group(1)
        # 处理转义字符
        json_str = json_str.replace('\\"', '"')
        return json.loads(json_str)
    return None


# 读取所有数据文件
base_dir = "D:/desktop/work/.dumate"
files = [
    ("page1_with_id.json", "贝乐妥"),
    ("page2_with_id.json", "贝乐妥"),
    ("page3_with_id.json", "贝乐妥"),
    ("kangshutuo_with_id.json", "康舒妥"),
    ("hongbotai_with_id.json", "弘博泰"),
]

all_drugs = []
for filename, drug_type in files:
    filepath = os.path.join(base_dir, filename)
    try:
        data = extract_json_from_file(filepath)
        if data and "drugs" in data:
            for d in data["drugs"]:
                d["drug_type"] = drug_type
                all_drugs.append(d)
            print(f"读取 {filename}: {len(data['drugs'])} 条")
        else:
            print(f"读取 {filename} 失败: 无法提取JSON")
    except Exception as e:
        print(f"读取 {filename} 失败: {e}")

print(f"\n总共读取: {len(all_drugs)} 条")

# 去重（基于wholesaleid）
seen = set()
unique_drugs = []
for d in all_drugs:
    wid = d.get("wholesaleid", "")
    if wid and wid not in seen:
        seen.add(wid)
        unique_drugs.append(d)

print(f"去重后: {len(unique_drugs)} 条")

# 生成CSV
output_file = "D:/desktop/work/药师帮_数据_20260415_v2.csv"
with open(output_file, "w", encoding="utf-8-sig", newline="") as f:
    writer = csv.writer(f)
    writer.writerow(
        [
            "序号",
            "店铺名",
            "商品名",
            "通用名",
            "规格",
            "价格",
            "折后价",
            "起购量",
            "生产日期",
            "有效期至",
            "生产厂家",
            "是否近效期",
            "配送说明",
            "统计时间",
            "商品URL",
        ]
    )

    for i, d in enumerate(unique_drugs, 1):
        wid = d.get("wholesaleid", "")
        url = f"https://dian.ysbang.cn/#/drugDetail?id={wid}" if wid else ""
        writer.writerow(
            [
                i,
                d.get("shop", ""),
                d.get("product", ""),
                d.get("drugName", ""),
                d.get("spec", ""),
                d.get("price", ""),
                d.get("zkPrice", ""),
                d.get("minQty", ""),
                d.get("prodDate", ""),
                d.get("validDate", ""),
                d.get("factory", ""),
                d.get("isNear", ""),
                d.get("delivery", ""),
                d.get("today", ""),
                url,
            ]
        )

print(f"\nCSV已生成: {output_file}")
