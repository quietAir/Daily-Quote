async page => {
  const result = await page.evaluate(() => {
    // 合并所有页面数据
    const all = [
      ...(window._page1 || []),
      ...(window._page2 || []),
      ...(window._page3 || [])
    ];
    
    // 去重
    const seen = new Set();
    const unique = all.filter(d => {
      const k = d.shop + '|' + d.product + '|' + d.spec + '|' + d.price + '|' + d.zkPrice + '|' + d.minQty;
      return seen.has(k) ? false : (seen.add(k), true);
    });
    
    // 生成CSV
    const headers = ['序号','店铺名','商品名','通用名','规格','价格','折后价','起购量',
                    '生产日期','有效期至','生产厂家','是否近效期','配送说明','统计时间','商品URL'];
    const csvRows = [headers.join(',')];
    
    unique.forEach((r, i) => {
      const row = [
        i + 1,
        `"${(r.shop || '').replace(/"/g, '""')}"`,
        `"${(r.product || '').replace(/"/g, '""')}"`,
        `"${(r.drugName || '').replace(/"/g, '""')}"`,
        `"${(r.spec || '').replace(/"/g, '""')}"`,
        r.price || '',
        r.zkPrice || '',
        `"${(r.minQty || '').replace(/"/g, '""')}"`,
        `"${(r.prodDate || '').replace(/"/g, '""')}"`,
        `"${(r.validDate || '').replace(/"/g, '""')}"`,
        `"${(r.factory || '').replace(/"/g, '""')}"`,
        `"${(r.isNear || '').replace(/"/g, '""')}"`,
        `"${(r.delivery || '').replace(/"/g, '""')}"`,
        `"${(r.today || '').replace(/"/g, '""')}"`,
        `"${(r.url || '').replace(/"/g, '""')}"`
      ];
      csvRows.push(row.join(','));
    });
    
    const csvContent = '\ufeff' + csvRows.join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    
    return { 
      total: unique.length, 
      csvUrl: url,
      csvContent: csvContent.substring(0, 2000) // 返回部分内容用于验证
    };
  });
  
  return result;
}
